package edu.miu.cs.alvin.music_streaming_app_backend.client;

public interface ClientRepository {
}
