package edu.miu.cs.alvin.music_streaming_app_backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MusicStreamingAppBackendApplication {

    public static void main(String[] args) {
        SpringApplication.run(MusicStreamingAppBackendApplication.class, args);
    }

}
